#ifndef LR_TEST_PACKAGE_DOWNLOADER_H
#define LR_TEST_PACKAGE_DOWNLOADER_H

#include <check.h>

Suite *package_downloader_suite(void);

#endif
