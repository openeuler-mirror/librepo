#define _GNU_SOURCE
#include <fcntl.h>
#include <dirent.h>
#include <errno.h>
#include <wordexp.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "testsys.h"

