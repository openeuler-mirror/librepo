#ifndef LR_TEST_REPOCONF_H
#define LR_TEST_REPOCONF_H

#include <check.h>

Suite *repoconf_suite(void);

#endif
