#ifndef LR_TEST_METALINK_H
#define LR_TEST_METALINK_H

#include <check.h>

Suite *metalink_suite(void);

#endif
