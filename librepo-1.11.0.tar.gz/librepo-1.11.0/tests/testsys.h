#ifndef LR_TESTSYS_H
#define LR_TESTSYS_H

#define UNITTEST_DIR "/tmp/librepoXXXXXX"

#endif
