.. _packagetarget:

PackageTarget (librepo.PackageTarget)
=====================================

.. autoclass:: librepo.PackageTarget
   :members:
