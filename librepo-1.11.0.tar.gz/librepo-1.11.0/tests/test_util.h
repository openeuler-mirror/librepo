#ifndef LR_TEST_UTIL_H
#define LR_TEST_UTIL_H

#include <check.h>

Suite *util_suite(void);

#endif
