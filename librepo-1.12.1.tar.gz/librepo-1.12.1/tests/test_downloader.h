#ifndef LR_TEST_DOWNLOADER_H
#define LR_TEST_DOWNLOADER_H

#include <check.h>

Suite *downloader_suite(void);

#endif
